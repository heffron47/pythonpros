
import wx



class MyForm(wx.Frame):
 
    #----------------------------------------------------------------------
    def __init__(self):
        wx.Frame.__init__(self, None, wx.ID_ANY, 
                          "Perk Ordering System")

      
        

        self.submitBttn=wx.Button(self, label='Submit', pos= (305,420),size = wx.Size(120,-1))
        self.continueBttnP2= wx.Button(self, label = 'Continue', pos = (325,580))
        self.backBttnP2= wx.Button(self, label = 'Back', pos = (210,580))
        self.continueBttnP2.Hide()
        self.backBttnP2.Hide()
        self.continueBttnP3= wx.Button(self, label = 'Continue', pos = (325,560))
        self.backBttnP3= wx.Button(self, label = 'Back', pos = (210,560))
        self.continueBttnP3.Hide()
        self.backBttnP3.Hide()
        self.continueBttnP4= wx.Button(self, label = 'Continue', pos = (325,700))
        self.backBttnP4= wx.Button(self, label = 'Back', pos = (210,700))
        self.continueBttnP4.Hide()
        self.backBttnP4.Hide()
        self.continueBttnP5= wx.Button(self, label = 'Place Order', pos = (325,600))
        self.backBttnP5= wx.Button(self, label = 'Back', pos = (210,600))
        self.continueBttnP5.Hide()
        self.backBttnP5.Hide()
        self.continueBttnP6= wx.Button(self, label = 'Email Receipt', pos = (325,700))
        self.backBttnP6= wx.Button(self, label = 'Back', pos = (210,700))
        self.continueBttnP6.Hide()
        self.backBttnP6.Hide()

        

       
        

        self.panel_one = PanelOne(self)
        self.panel_two = PanelTwo(self)
        self.panel_three = PanelThree(self)
        self.panel_four = PanelFour(self)
        self.panel_five = PanelFive(self)
        self.panel_six = PanelSix(self)

        self.panel_two.Hide()
        self.panel_three.Hide()
        self.panel_four.Hide()
        self.panel_five.Hide()
        self.panel_six.Hide()

    
        self.sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer.Add(self.panel_one, 1, wx.EXPAND)
        self.sizer.Add(self.panel_two, 1, wx.EXPAND)
        self.sizer.Add(self.panel_three,1, wx.EXPAND)
        self.sizer.Add(self.panel_four,1, wx.EXPAND)
        self.sizer.Add(self.panel_five,1, wx.EXPAND)
        self.sizer.Add(self.panel_six, 1, wx.EXPAND)
        self.SetSizer(self.sizer)

        self.SetClientSize(600,800)
        self.MaxImageSize=500
        self.Image = wx.StaticBitmap(self, bitmap=wx.Bitmap(self.MaxImageSize, self.MaxImageSize))
        Img = wx.Image('app\MicrosoftTeams-image.png', wx.BITMAP_TYPE_ANY)
        Img = Img.Scale(200,200,quality=wx.IMAGE_QUALITY_HIGH)
        self.Image.SetBitmap(wx.Bitmap(Img))
        
        color = wx.Colour(234,218,244)
        self.SetBackgroundColour(color)
        self.Image.SetPosition((200, 0))
        self.submitBttn.Bind(wx.EVT_BUTTON, self.onSwitchPanels)
        
        

        
        
    def reverseTo1(self, event):


                                                              
            print('showing panel 1')
            self.panel_two.Hide()
            self.continueBttnP2.Hide()                                                                                                                      
            self.backBttnP2.Hide()                              
            self.submitBttn.Show()                                                                                                                                                                                                                                                                                         
            self.panel_one.Show()
            self.Layout()

    def reverseTo2(self, event):


                                                              
            print('showing panel 2')
            self.panel_three.Hide()
            self.continueBttnP3.Hide()                                                                                                                      
            self.backBttnP3.Hide()                              
            self.continueBttnP2.Show()
            self.backBttnP2.Show()                                                                                                                                                                                                                                                                                         
            self.panel_two.Show()
            self.Layout()

    def reverseTo3(self, event):


                                                              
            print('showing panel 3')
            self.panel_four.Hide()
            self.continueBttnP4.Hide()                                                                                                                      
            self.backBttnP4.Hide()                              
            self.continueBttnP3.Show()
            self.backBttnP3.Show()                                                                                                                                                                                                                                                                                         
            self.panel_three.Show()
            self.Layout()

    def reverseTo4(self, event):


                                                              
            print('showing panel 4')
            self.panel_five.Hide()
            self.continueBttnP5.Hide()                                                                                                                      
            self.backBttnP5.Hide()                              
            self.continueBttnP4.Show()
            self.backBttnP4.Show()                                                                                                                                                                                                                                                                                         
            self.panel_four.Show()
            self.Layout()

    def reverseTo5(self, event):


                                                              
            print('showing panel 5')
            self.panel_six.Hide()
            self.continueBttnP6.Hide()                                                                                                                      
            self.backBttnP6.Hide()                              
            self.continueBttnP5.Show()
            self.backBttnP5.Show()                                                                                                                                                                                                                                                                                         
            self.panel_five.Show()
            self.Layout()
        
        

    def onSwitchPanels(self, event):
        """"""
        if self.panel_one.IsShown():
            print('showing panel 2')
            self.submitBttn.Hide()
            self.panel_one.Hide()
            self.panel_two.Show()
            self.continueBttnP2.Show()
            self.backBttnP2.Show()
            self.backBttnP2.Bind(wx.EVT_BUTTON, self.reverseTo1)
            self.continueBttnP2.Bind(wx.EVT_BUTTON, self.onSwitchPanels)
        elif self.panel_two.IsShown():
            print('showing panel 3')
            self.continueBttnP2.Hide()
            self.backBttnP2.Hide()
            self.panel_two.Hide()
            self.continueBttnP3.Show()
            self.backBttnP3.Show()
            self.panel_three.Show()
            self.backBttnP3.Bind(wx.EVT_BUTTON, self.reverseTo2)
            self.continueBttnP3.Bind(wx.EVT_BUTTON, self.onSwitchPanels)
        elif self.panel_three.IsShown():
            print('showing panel 4')
            self.continueBttnP3.Hide()
            self.backBttnP3.Hide()
            self.continueBttnP4.Show()
            self.backBttnP4.Show()
            self.panel_three.Hide()
            self.panel_four.Show()
            self.backBttnP4.Bind(wx.EVT_BUTTON, self.reverseTo3)
            self.continueBttnP4.Bind(wx.EVT_BUTTON, self.onSwitchPanels)
        elif self.panel_four.IsShown():
            print('showing panel 5')
            self.continueBttnP4.Hide()
            self.backBttnP4.Hide()
            self.continueBttnP5.Show()
            self.backBttnP5.Show()
            self.panel_four.Hide()
            self.panel_five.Show()
            self.backBttnP5.Bind(wx.EVT_BUTTON, self.reverseTo4)
            self.continueBttnP5.Bind(wx.EVT_BUTTON, self.onSwitchPanels)
        elif self.panel_five.IsShown():
            print('showing panel 6')
            self.continueBttnP5.Hide()
            self.backBttnP5.Hide()
            self.continueBttnP6.Show()
            self.backBttnP6.Show()
            self.panel_five.Hide()
            self.panel_six.Show()
            self.backBttnP6.Bind(wx.EVT_BUTTON, self.reverseTo5)
            self.continueBttnP6.Bind(wx.EVT_BUTTON, self.onSwitchPanels)
        self.Layout()


class PanelOne(wx.Panel):
   
    #----------------------------------------------------------------------
    def __init__(self, parent):
        """Constructor"""
        wx.Panel.__init__(self, parent=parent)
        self.LoginTitle = wx.StaticText(self, label = "User Authentication",  pos = (185,220),size=wx.DefaultSize)
        self.Username = wx.StaticText(self, wx.ID_ANY, 'Username', pos = (235, 288) )
        self.inputUsername = wx.TextCtrl(self, wx.ID_ANY, pos = (235,305))
        self.Password = wx.StaticText(self, wx.ID_ANY, 'Password', pos = (235, 348) )
        self.inputPassword = wx.TextCtrl(self, wx.ID_ANY, pos = (235,367), style = wx.TE_PASSWORD)
        
        self.forgotBttn=wx.Button(self, label='Forgot Password', pos= (150,420), size = wx.Size(120,-1))
        
        font = wx.Font(20, family = wx.FONTFAMILY_DECORATIVE, style = 2, weight = wx.FONTWEIGHT_THIN, 
                      underline = True, faceName ="Montserrat", encoding = wx.FONTENCODING_DEFAULT)
        self.LoginTitle.SetFont(font)
        color = wx.Colour(234,218,244)
        self.LoginTitle.SetBackgroundColour(color)
        self.forgotBttn.Bind(wx.EVT_BUTTON, self.ShowDialog)
        

    def ShowDialog(self, event):

            
        self.dlg = wx.RichMessageDialog(parent=None, 
                                        message='Please contact administrator to reset your password', caption='Message box',
                                        style=wx.CANCEL|wx.CENTRE)
            
        self.dlg.ShowModal()
        
 

class PanelTwo(PanelOne):
    
    #----------------------------------------------------------------------
    def __init__(self, parent):
        """Constructor"""
        
        wx.Panel.__init__(self, parent=parent)
        font = wx.Font(20, family = wx.FONTFAMILY_DEFAULT, style = 2, weight = 90, 
                      underline = True, faceName ="Montserrat", encoding = wx.FONTENCODING_DEFAULT)
        
        self.CustomerInfo = wx.StaticText(self, label ='Customer Information', pos =(175,220))
        self.CustomerInfo.SetFont(font)
        self.nowRadioBttn = wx.RadioButton(self, label = 'New', pos = (215, 270))
        self.retRadioBttn = wx.RadioButton(self, label = 'Returning', pos = (315, 270))
        self.firstName = wx.StaticText(self, label ='First Name', pos =(215,330))
        self.inputFN = wx.TextCtrl(self, wx.ID_ANY, pos = (215,350),size = wx.Size(180,-1))
        self.lastName = wx.StaticText(self, label ='Last Name', pos =(215,390))
        self.inputLN = wx.TextCtrl(self, wx.ID_ANY, pos = (215,410),size = wx.Size(180,-1))
        self.Email = wx.StaticText(self, label ='Email', pos =(215,450))
        self.inputEmail = wx.TextCtrl(self, wx.ID_ANY, pos = (215,470),size = wx.Size(180,-1))
        self.phoneNum = wx.StaticText(self, label ='Phone Number', pos =(215,510))
        self.inputPN = wx.TextCtrl(self, wx.ID_ANY, pos = (215,530),size = wx.Size(180,-1))
        


class PanelThree(PanelTwo):
    def __init__(self, parent):
        """Constructor"""
        
        wx.Panel.__init__(self, parent=parent)
        font = wx.Font(20, family = wx.FONTFAMILY_DEFAULT, style = 2, weight = 90, 
                      underline = True, faceName ="Montserrat", encoding = wx.FONTENCODING_DEFAULT)

        self.OrderDetails = wx.StaticText(self, label ='Order Details', pos =(225,220))
        self.OrderDetails.SetFont(font)
        self.basketLabel = wx.StaticText(self, label ='Select Your Basket', pos =(215,310))
        self.basketSelect = wx.Choice(self, choices=['A', 'B', 'C'], pos = (215,330), size = wx.Size(180,-1))
        self.giftLabel = wx.StaticText(self, label ='Extra Gift', pos =(215,370))
        self.extraGift = wx.Choice(self, choices=['A', 'B', 'C'], pos = (215,390), size = wx.Size(180,-1))
        self.colorLabel = wx.StaticText(self, label ='Color Theme', pos =(215,430))
        self.colorSelect = wx.Choice(self, choices=['A', 'B', 'C'], pos = (215,450), size = wx.Size(180,-1))
        self.quantityLabel = wx.StaticText(self, label ='Quantity', pos =(215,490))
        self.qSelect = wx.SpinCtrl(self, wx.ID_ANY, value="0", min=0, max=100, pos =(275, 510), size=wx.Size(60,-1))
        
        
        
class PanelFour(PanelThree):
    
    #----------------------------------------------------------------------
    def __init__(self, parent):
        """Constructor"""
        
        wx.Panel.__init__(self, parent=parent)   
        font = wx.Font(20, family = wx.FONTFAMILY_DEFAULT, style = 2, weight = 90, 
                      underline = True, faceName ="Montserrat", encoding = wx.FONTENCODING_DEFAULT)
        self.shippingInfo = wx.StaticText(self, label ='Shipping Information', pos =(180,220))
        self.shippingInfo.SetFont(font)
        delivfont = wx.Font(12, family = wx.FONTFAMILY_DEFAULT, style = 2, weight = 90, 
                      underline = False, faceName ="Montserrat", encoding = wx.FONTENCODING_DEFAULT)
        #self.delivLabel = wx.StaticText(self, label ='Delivery Type', pos =(185,290))
        #self.delivLabel.SetFont(delivfont)
        self.personalRadioBttn = wx.RadioButton(self, label = 'Personal Delivery', pos = (190, 290))
        self.uspsRadioBttn = wx.RadioButton(self, label = 'USPS', pos = (340, 290))
        self.addressLabel = wx.StaticText(self, label = 'Street Address', pos = (215, 330))
        self.inputAdd = wx.TextCtrl(self, wx.ID_ANY, pos = (215,350),size = wx.Size(180,-1))
        self.cityLabel = wx.StaticText(self, label = 'City', pos = (215, 390))
        self.inputCity = wx.TextCtrl(self, wx.ID_ANY, pos = (215,410),size = wx.Size(180,-1))
        self.stateLabel = wx.StaticText(self, label = 'State', pos = (215, 450))
        self.stateSelect = wx.Choice(self, choices=['A', 'B', 'C'], pos = (215,470), size = wx.Size(180,-1))
        self.zipLabel = wx.StaticText(self, label = 'Zip Code', pos = (215, 510))
        self.inputZip = wx.TextCtrl(self, wx.ID_ANY, pos = (215,530),size = wx.Size(180,-1))
        self.countryLabel = wx.StaticText(self, label = 'Country', pos = (215, 570))
        self.inputCountry = wx.TextCtrl(self, wx.ID_ANY, pos = (215,590),size = wx.Size(180,-1))
        self.dateLabel = wx.StaticText(self, label = 'Delivery Date', pos = (215, 630))
        self.inputDate = wx.TextCtrl(self, wx.ID_ANY, pos = (215,650),size = wx.Size(180,-1))
      

class PanelFive(PanelFour):
    
    #----------------------------------------------------------------------
    def __init__(self, parent):
        """Constructor"""
        
        wx.Panel.__init__(self, parent=parent)
        
        

        self.MaxImageSize=500
        self.Visa = wx.StaticBitmap(self, bitmap=wx.Bitmap(self.MaxImageSize, self.MaxImageSize))
        visaImg = wx.Image('app\Visa.png', wx.BITMAP_TYPE_ANY)
        vImg = visaImg.Scale(60,50,quality=wx.IMAGE_QUALITY_HIGH)
        self.Visa.SetBitmap(wx.Bitmap(vImg))
        

        self.MaxImageSize=500
        self.amex = wx.StaticBitmap(self, bitmap=wx.Bitmap(self.MaxImageSize, self.MaxImageSize))
        amexImg = wx.Image("app\Amex.png", wx.BITMAP_TYPE_ANY)
        amImg = amexImg.Scale(80,50,quality=wx.IMAGE_QUALITY_HIGH)
        self.amex.SetBitmap(wx.Bitmap(amImg))
        

        self.MaxImageSize=500
        self.masterCard = wx.StaticBitmap(self, bitmap=wx.Bitmap(self.MaxImageSize, self.MaxImageSize))
        masterImg = wx.Image('app\mastercard.jpg', wx.BITMAP_TYPE_ANY)
        mcImg = masterImg.Scale(80,50,quality=wx.IMAGE_QUALITY_HIGH)
        self.masterCard.SetBitmap(wx.Bitmap(mcImg))

        self.MaxImageSize=500
        self.discover = wx.StaticBitmap(self, bitmap=wx.Bitmap(self.MaxImageSize, self.MaxImageSize))
        discoverImg = wx.Image('app\discover.png', wx.BITMAP_TYPE_ANY)
        discImg = discoverImg.Scale(80,50,quality=wx.IMAGE_QUALITY_HIGH)
        self.discover.SetBitmap(wx.Bitmap(discImg))

        self.Visa.SetPosition((85, 300))
        self.amex.SetPosition((200, 300))
        self.masterCard.SetPosition((325, 300))
        self.discover.SetPosition((450, 300))

        self.visaRadioBttn = wx.RadioButton(self, pos = (70, 300))
        self.amexRadioBttn = wx.RadioButton(self,  pos = (185, 300))
        self.mastercardRadioBttn = wx.RadioButton(self,  pos = (310, 300))
        self.discoverRadioBttn = wx.RadioButton(self,   pos = (435, 300))

        font = wx.Font(20, family = wx.FONTFAMILY_DEFAULT, style = 2, weight = 90, 
                      underline = True, faceName ="Montserrat", encoding = wx.FONTENCODING_DEFAULT)
        
        self.paymentInfo = wx.StaticText(self, label ='Payment Information', pos =(180,220))
        self.paymentInfo.SetFont(font)
        
        self.cardNameLabel = wx.StaticText(self, label = 'Full Name on Card', pos = (215, 390))
        self.inputcardName = wx.TextCtrl(self, wx.ID_ANY, pos = (215,410),size = wx.Size(180,-1))
        self.cardNumberLabel = wx.StaticText(self, label = 'Card Number', pos = (215, 450))
        self.inputcardNumber = wx.TextCtrl(self, wx.ID_ANY, pos = (215,470),size = wx.Size(180,-1))
        self.cardExpLabel = wx.StaticText(self, label = 'Expiration Date', pos = (215, 510))
        self.inputcardExp = wx.TextCtrl(self, wx.ID_ANY, pos = (215,530),size = wx.Size(120,-1))
        self.cardCSVLabel = wx.StaticText(self, label = 'CSV', pos = (355, 510))
        self.inputcardCSV = wx.TextCtrl(self, wx.ID_ANY, pos = (355,530),size = wx.Size(40,-1))
        
class PanelSix(PanelFive):
    
    #----------------------------------------------------------------------
    def __init__(self, parent):
        """Constructor"""
        
        wx.Panel.__init__(self, parent=parent)
        
        
        font = wx.Font(20, family = wx.FONTFAMILY_DEFAULT, style = 2, weight = 90, 
                      underline = True, faceName ="Montserrat", encoding = wx.FONTENCODING_DEFAULT)

        self.receipt = wx.StaticText(self, label ='Receipt', pos =(260,220))
        self.receipt.SetFont(font)

        self.ordernumberLabel = wx.StaticText(self, label = 'Order Number', pos = (215, 310))
        self.ordernumber = wx.TextCtrl(self, wx.ID_ANY, pos = (215,330),size = wx.Size(180,-1))
        self.ordernumber.SetEditable(False)
        
        self.productorderedLabel = wx.StaticText(self, label = 'Product Ordered', pos = (215, 370))
        self.productordered = wx.TextCtrl(self, wx.ID_ANY, pos = (215,390),size = wx.Size(180,-1))
        self.productordered.SetEditable(False)
        self.quantityLabel = wx.StaticText(self, label = 'Quantity', pos = (215, 430))
        self.displayQuantity = wx.TextCtrl(self, wx.ID_ANY, pos = (215,450),size = wx.Size(180,-1))
        self.displayQuantity.SetEditable(False)
        self.subtotalLabel = wx.StaticText(self, label = 'Subtotal', pos = (215, 500))
        self.displaySubtotal = wx.TextCtrl(self, wx.ID_ANY, pos = (275,500),size = wx.Size(120,-1))
        self.displaySubtotal.SetEditable(False)
        self.taxLabel = wx.StaticText(self, label = 'Tax (8.5%)', pos = (215, 560))
        self.displayTax = wx.TextCtrl(self, wx.ID_ANY, pos = (275,560),size = wx.Size(120,-1))
        self.displayTax.SetEditable(False)
        self.totalLabel = wx.StaticText(self, label = 'Total', pos = (215, 620))
        self.displayTotal = wx.TextCtrl(self, wx.ID_ANY, pos = (275,620),size = wx.Size(120,-1))
        self.displayTotal.SetEditable(False)

if __name__ == '__main__':
    
    app = wx.App()
    ex = MyForm()
    ex.Show()
    app.MainLoop()